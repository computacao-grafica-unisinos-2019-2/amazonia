/*******************************************************************
** This code is part of Breakout.
**
** Breakout is free software: you can redistribute it and/or modify
** it under the terms of the CC BY 4.0 license as published by
** Creative Commons, either version 4 of the License, or (at your
** option) any later version.
******************************************************************/
#include <iostream>
#include <sstream>
#include "Game.h"
#include "ResourceManager.h"
#include "SpriteRenderer.h"
#include "GameObject.h"
#include "GameConfig.cpp"
#include "TextRenderer.h"

// Game-related State data
SpriteRenderer  *Renderer;
GameObject      *Player;
GameObject      *NPC;
GameObject      *Mushroom;
GameObject      *Mushroom2;
GameObject      *Mushroom3;

TextRenderer *Text;

GLfloat         offset = 0.0f;


Game::Game(GLuint width, GLuint height)
        : State(GAME_ACTIVE), Keys(), Width(width), Height(height)
{

}

Game::~Game()
{
    delete Renderer;
    delete Player;
    delete NPC;
}

void Game::Init()
{
    // Load shaders
    ResourceManager::LoadShader("resources/shaders/sprite/sprite.vert", "resources/shaders/sprite/sprite.frag", nullptr, "sprite");

    // Configure shaders
    glm::mat4 projection = glm::ortho(0.0f, static_cast<GLfloat>(this->Width), static_cast<GLfloat>(this->Height), 0.0f, -1.0f, 1.0f);
    ResourceManager::GetShader("sprite").Use().SetInteger("sprite", 0);
    ResourceManager::GetShader("sprite").SetMatrix4("projection", projection);
    // Load textures
    ResourceManager::LoadTexture("resources/textures/sprites/run.png", GL_TRUE,"elf");
    ResourceManager::LoadTexture("resources/textures/sprites/orc/running.png",GL_TRUE, "orc");
    ResourceManager::LoadTexture("resources/textures/background.png",GL_TRUE, "forest");
    ResourceManager::LoadTexture("resources/textures/mushroom.png",GL_TRUE, "mush");

    ResourceManager::LoadTexture("resources/textures/background/forest/1.png", GL_FALSE,"forest1");
    ResourceManager::LoadTexture("resources/textures/background/forest/2.png", GL_FALSE,"forest2");
    ResourceManager::LoadTexture("resources/textures/background/forest/3.png", GL_FALSE,"forest3");
    ResourceManager::LoadTexture("resources/textures/background/forest/4.png", GL_FALSE,"forest4");
    ResourceManager::LoadTexture("resources/textures/background/forest/5.png", GL_FALSE,"forest5");

    // Set render-specific controls
    Shader shader = ResourceManager::GetShader("sprite");
    Renderer = new SpriteRenderer(shader);

    Texture2D elfSprite = ResourceManager::GetTexture("elf");
    Texture2D orcSprite = ResourceManager::GetTexture("orc");
    Texture2D mushSprite = ResourceManager::GetTexture("mush");

    Mushroom = new GameObject(glm::vec3(400, 480, -0.2f), glm::vec2(50, 50), mushSprite);
    Mushroom2 = new GameObject(glm::vec3(500, 480, -0.2f), glm::vec2(50, 50), mushSprite);
    Mushroom3 = new GameObject(glm::vec3(600, 480, -0.2f), glm::vec2(50, 50), mushSprite);

    Player = new GameObject(glm::vec3(50, 340, -0.1f), glm::vec2(150, 200), elfSprite, 5);
    Player->Vida = 100;
    NPC = new GameObject(glm::vec3(800, 340, -0.1f), glm::vec2(150, 200), orcSprite, 14);

    Text = new TextRenderer(this->Width, this->Height);
    Text->Load("resources/fonts/OCRAEXT.TTF", 24);
}

void Game::Update(GLfloat dt)
{
    if ((!Mushroom->Destroyed) &&
         this->CheckCollision(*Player, *Mushroom)){
        Mushroom->Destroyed = true;
        Player->Vida -= 10;
    }

    if ((!Mushroom2->Destroyed) &&
        this->CheckCollision(*Player, *Mushroom2)){
        Mushroom2->Destroyed = true;
        Player->Vida -= 10;
    }

    if ((!Mushroom3->Destroyed) &&
        this->CheckCollision(*Player, *Mushroom3)){
        Mushroom3->Destroyed = true;
        Player->Vida -= 10;
    }
}


void Game::ProcessInput(GLfloat dt)
{

    if (this->State == GAME_ACTIVE)
    {
        // Move playerboard
        if (this->Keys[GLFW_KEY_A])
        {
            Player->MoveLeft(dt);
        }
        if (this->Keys[GLFW_KEY_D])
        {
            Player->MoveRight(dt);
        }
        if (this->Keys[GLFW_KEY_W])
        {
            Player->MoveUp(dt);
        }

        if (this->Keys[GLFW_KEY_S])
        {
            Player->MoveDown(dt);
        }

        if(GameConfig::MOVE_BG <= Player->Position.x){
            offset = offset +  0.001f;
            Mushroom->MoveLeft(dt);
        }

        ProcessNPC(dt);
    }
}

void Game::Render()
{

    if (this->State == GAME_ACTIVE)
    {
        Texture2D forestTexture = ResourceManager::GetTexture("forest");
        Renderer->DrawSprite(forestTexture, glm::vec3(0, 0, -0.2), glm::vec2(this->Width, this->Height), 0.0f, glm::vec3(1.0f), offset);

        Texture2D forest1Texture = ResourceManager::GetTexture("forest1");
        Texture2D forest2Texture = ResourceManager::GetTexture("forest2");
        Texture2D forest3Texture = ResourceManager::GetTexture("forest3");
        Texture2D forest4Texture = ResourceManager::GetTexture("forest4");
        Texture2D forest5Texture = ResourceManager::GetTexture("forest5");

        // Draw background
         //Renderer->DrawSprite(forest1Texture, glm::vec3(0, 0, -0.1), glm::vec2(this->Width, this->Height), 0.0f,glm::vec3(1.0f), offset);
         //Renderer->DrawSprite(forest2Texture, glm::vec3(0, 0, -0.4), glm::vec2(this->Width, this->Height), 0.0f,glm::vec3(1.0f), offset);
         //Renderer->DrawSprite(forest4Texture, glm::vec3(0, 0, -0.5f), glm::vec2(this->Width, this->Height), 0.0f,glm::vec3(1.0f), offset);
        // Renderer->DrawSprite(forest3Texture, glm::vec3(0, 0, -0.3f), glm::vec2(this->Width, this->Height), 0.0f,glm::vec3(1.0f), offset);
        // Renderer->DrawSprite(forest1Texture, glm::vec3(0, 0, -0.1), glm::vec2(this->Width, this->Height), 0.0f,glm::vec3(1.0f), offset);

        // Renderer->DrawSprite(forest5Texture, glm::vec3(0, 0, -0.45), glm::vec2(this->Width, this->Height), 0.0f,glm::vec3(1.0f), offset);

        // Draw player
        Player->Draw(*Renderer);
        NPC->Draw(*Renderer);

        if (!Mushroom->Destroyed)
            Mushroom->Draw(*Renderer);

        std::stringstream ss; ss << Player->Vida;
        Text->RenderText("Vida:"+ ss.str(), 5.0f, 5.0f, 1.0f);
    }
}

void Game::ProcessNPC(GLfloat dt) {
    NPC->MoveLeft(dt);
}

bool Game::CheckCollision(GameObject one, GameObject two) {
    // Collision x-axis?
    bool collisionX = one.Position.x + one.Size.x >= two.Position.x &&
                      two.Position.x + two.Size.x >= one.Position.x;
    // Collision y-axis?
    bool collisionY = one.Position.y + one.Size.y >= two.Position.y &&
                      two.Position.y + two.Size.y >= one.Position.y;
    // Collision only if on both axes
    return collisionX && collisionY;
}

