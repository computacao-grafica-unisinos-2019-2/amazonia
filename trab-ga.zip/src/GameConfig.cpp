//
// Created by Viegas, Jorge on 22/09/19.
//
#include <OpenGL/OpenGL.h>
class GameConfig {
public:
    constexpr static const GLfloat SCREEN_HEIGHT = 540;
    constexpr static const GLfloat SCREEN_WIDTH = 960;
    constexpr static const GLfloat MOVE_BG = 450;
    constexpr static const GLfloat MOVE_Y_LIMIT = 450;

};